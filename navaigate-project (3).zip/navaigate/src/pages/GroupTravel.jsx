import { Users } from 'lucide-react'

const GROUP_TRIPS = [
  { id: 1, dest: 'Goa', type: 'Adventure', date: 'May 15-20, 2026', price: '₹12,000/person', spots: '4/8 spots', via: 'WhatsApp', color: 'from-teal-500 to-cyan-400', img: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=200&q=80' },
  { id: 2, dest: 'Ladakh', type: 'Adventure', date: 'Jun 5-14, 2026', price: '₹35,000/person', spots: '2/6 spots', via: 'Telegram', color: 'from-blue-500 to-indigo-400', img: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&q=80' },
  { id: 3, dest: 'Rishikesh', type: 'Spiritual', date: 'May 1-9, 2026', price: '₹8,000/person', spots: '5/10 spots', via: 'WhatsApp', color: 'from-amber-500 to-orange-400', img: 'https://images.unsplash.com/photo-1591018533415-dcd4ed6be73e?w=200&q=80' },
  { id: 4, dest: 'Manali', type: 'Adventure', date: 'Jun 20-28, 2026', price: '₹14,000/person', spots: '3/8 spots', via: 'WhatsApp', color: 'from-green-500 to-emerald-400', img: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=200&q=80' },
  { id: 5, dest: 'Kerala Backwaters', type: 'Romantic', date: 'Jul 10-15, 2026', price: '₹18,000/person', spots: '6/8 spots', via: 'WhatsApp', color: 'from-purple-500 to-violet-400', img: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?w=200&q=80' },
]

const TYPE_COLORS = {
  Adventure: 'bg-teal-500/20 text-teal-400',
  Spiritual: 'bg-purple-500/20 text-purple-400',
  Romantic: 'bg-pink-500/20 text-pink-400',
}

export default function GroupTravel() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <div className="section-tag mx-auto w-fit"><Users className="w-3.5 h-3.5" /> Group Travel</div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">
            Group <span className="gradient-text">Travel</span>
          </h1>
          <p className="text-slate-400 max-w-xl mx-auto">Don't travel alone! Join like-minded travelers heading to the same destination.</p>
        </div>

        {/* How it works */}
        <div className="card mb-10">
          <h3 className="font-display font-semibold text-white mb-6 text-center">How It Works</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            {[
              { n: '1', title: 'Pick a Trip', desc: 'Browse upcoming group trips or suggest your own destination' },
              { n: '2', title: 'Join the Group', desc: "Click join and we'll add you to a WhatsApp or Telegram group chat" },
              { n: '3', title: 'Travel Together', desc: 'Plan together, split costs, share experiences, and make lifelong friends' },
            ].map(({ n, title, desc }) => (
              <div key={n}>
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 text-teal-400 font-display font-bold flex items-center justify-center mx-auto mb-3">{n}</div>
                <h4 className="font-semibold text-white text-sm mb-1">{title}</h4>
                <p className="text-slate-500 text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        <h3 className="font-display font-semibold text-white text-xl mb-4">Upcoming Group Trips</h3>
        <div className="space-y-4">
          {GROUP_TRIPS.map(trip => (
            <div key={trip.id} className="card flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:border-teal-500/20 transition-all">
              <img src={trip.img} alt={trip.dest} className="w-full sm:w-16 h-40 sm:h-16 rounded-xl object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  <h4 className="font-display font-bold text-white text-lg">{trip.dest}</h4>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${TYPE_COLORS[trip.type] || 'bg-slate-500/20 text-slate-400'}`}>{trip.type}</span>
                </div>
                <div className="flex flex-wrap gap-3 text-sm text-slate-400">
                  <span>📅 {trip.date}</span>
                  <span>₹ {trip.price}</span>
                  <span>👥 {trip.spots}</span>
                </div>
                {/* Progress bar */}
                <div className="mt-2 w-full max-w-xs h-1.5 bg-navy-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${trip.color} rounded-full`}
                    style={{ width: `${(parseInt(trip.spots) / parseInt(trip.spots.split('/')[1])) * 100}%` }}
                  />
                </div>
              </div>
              <button className={`flex-shrink-0 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r ${trip.color} hover:opacity-90 transition-opacity flex items-center gap-2 shadow-lg`}>
                {trip.via === 'WhatsApp' ? '💬' : '✈️'} Join via {trip.via}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
